window.onload = pageLoad;

function pageLoad(){
	var from = document.getElementById("myForm");
    from.onsubmit = validateForm;

}

function validateForm() {
    
    var x = document.forms["myForm"]["password"].value;
    var y = document.forms["myForm"]["repassword"].value;
    if(x != y)
    {
        var from = document.getElementById("errormsg").innerHTML="กรุณาใส่รหัสใหม่ให้ถูก"; 
        alert("บ่ถูกจ้าน้องหล่า")
        return false;
    }
    else
    {
        alert("ถูกแล้วจ้าน้องหล่า")
    }
}




