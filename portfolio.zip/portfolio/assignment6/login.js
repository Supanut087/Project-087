window.onload = pageLoad;

function pageLoad(){
	var from = document.getElementById("myLogin");
    from.onsubmit = validateForm;
}

function validateForm() {
	const queryString = window.location.search;
	const urlParams = new URLSearchParams(queryString);
	const username = urlParams.get('username')
	const password = urlParams.get('password')

	var un = document.forms["myLogin"]["username"].value;
    var pn = document.forms["myLogin"]["password"].value;
    if(un != username || pn != password) 
    {
        alert("ยังไม่ถูกนะพี่");
        return false;
    }
    else
    {
        alert("ถูกแล้วจ้าเก่งมากก");
    }
	
}

